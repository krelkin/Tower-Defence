function Display(image_src = "", width = 1024, height = 768){
	this.field_image = undefined;
	this.field_width = width;
	this.field_height = height;
	this.canvas == undefined;
	this.frame = 0;
	
	this.initField = function(image_src, width, height){
		if(this.canvas === undefined){
			canvas = $("<canvas>", {id: "canvas_field", style:"position:fixed;z-index:50"})[0];
			canvas.width = width;
			canvas.height= height + 200; // 200 - высота интерфейса
			$("#field").append(canvas);
			this.canvas = canvas.getContext("2d");
		}
		if(image_src != ""){
			/*img = new Image();
			img.src = image_src;*/
			//img = $("<img>", {src: image_src, style: "width:this.field_width;height:this.field_height"})[0];
			$("#field").append( $("<img>", {src: image_src, style: "width:this.field_width;height:this.field_height;position:fixed"}) );
			//this.field_image = img;
			//this.canvas.save();
		}
	}
	
	this.drawInterfaceParams = function(title, param, current_position){
		this.canvas.fillText(title + ": " + param, current_position["left"], current_position["top"]);
	}
	
	this.drawTower = function(tower){
		if(tower.id != "tower_interface"){
			var action = tower.action;
			var vector = tower.vector;
		}else{	
			var action = tower_params[tower.type]["tower_interface_action"];
			var vector = tower_params[tower.type]["tower_interface_vector"];
		}
		var tower_animation_param = tower_params[tower.type].animation[action][vector];
		
		if(tower.show_radius){
			var radius = tower_params[tower.type].radius;
			this.canvas.beginPath();
			this.canvas.arc(tower.current_position["left"], tower.current_position["top"], radius, 0, 2 * Math.PI);
			this.canvas.save();
			this.canvas.fillStyle = "rgba(0,255,155,0.5)";
			this.canvas.fill();
			this.canvas.lineWidth = 1;
			this.canvas.strokeStyle = 'red';
			this.canvas.stroke();
			this.canvas.restore();
		}
		
		if(tower_animation_param.count_frames_width == 0 && tower_animation_param.count_frames_width == 0){
			//translate()
			this.canvas.drawImage(
				tower.animation[action][vector][tower.frame],
				tower.current_position["left"] - (tower_animation_param.frame_width / 2),
				tower.current_position["top"] - (tower_animation_param.frame_height / 2)
			);
			/*this.canvas.fillText(tower.health,
								tower.current_position["left"],
								tower.current_position["top"] - (tower_animation_param.frame_height / 2) + 10
								);*/
		}else{
			var frame_tower = tower.frame;
			if (tower_animation_param.start_from[0] != 0 || tower_animation_param.start_from[1] != 0){
				var remove_frames = tower_animation_param["count_frames_width"] + 1 + tower_animation_param["start_from"][0] +
								tower_animation_param["count_frames_width"] * (tower_animation_param["start_from"][1] - 1) - 1;
				frame_tower += remove_frames;
			}
			var frames_height = 1;
			var x = 0;
			var y = 0;
			if(frame_tower < tower_animation_param["count_frames_width"]){
				x = frame_tower;
			}else{
				y = Math.floor(frame_tower / tower_animation_param.count_frames_width);
				x = frame_tower - y * (tower_animation_param.count_frames_width);
			}
			this.canvas.drawImage(
				tower.animation[action][vector],     				//Объект Image анимации 
				Math.round(tower_animation_param.frame_width * x), 	//Берем текущий кадр, ширина кадра * шаг анимации
				Math.round(tower_animation_param.frame_height * y), //Берем текущий кадр, высота кадра * шаг анимации
				tower_animation_param.frame_width,      			//Вырез в ширину объекта
				tower_animation_param.frame_height,     			//И в высоту
				tower.current_position["left"] - (tower_animation_param.frame_width / 2),//Размещаем по горизонтали на холсте
				tower.current_position["top"] - (tower_animation_param.frame_height / 2),//И по вертикали
				tower_animation_param.frame_width,      			//Ширина как у кадра
				tower_animation_param.frame_height      			//Ну и высота
		);
		}
	}
	
	this.drawNewTower = function(tower_left, tower_top){

	}
	
	this.drawEnemy = function(enemy, action){
		if(enemy_params[enemy.type].count_frames_width == 0 && enemy_params[enemy.type].count_frames_width == 0){
			//translate()
			this.canvas.drawImage(
				enemy.animation[action][enemy.vector][enemy.frame],
				enemy.current_position["left"] - (enemy_params[enemy.type].animation[action][enemy.vector].frame_width / 2),
				enemy.current_position["top"] - (enemy_params[enemy.type].animation[action][enemy.vector].frame_height / 2)
			);
			this.canvas.fillText(enemy.health,
								enemy.current_position["left"],
								enemy.current_position["top"] - (enemy_params[enemy.type].animation[action][enemy.vector].frame_height / 2) + 10
								);
		}else{
			
		}
	}
	
	this.drawField = function(image_src = "", new_field = false){
		if(this.field_image === undefined || new_field == true){
			this.initCanvas(image_src);
		}
	}
	
	this.initField(image_src, width, height);
}
