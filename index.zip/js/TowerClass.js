﻿function Tower(id, type, current_position){
	//PROPERTIES
	selfTower = this;
	this.id = id;			//id башенки
	this.type = type;		//тип башенки
	this.current_position = current_position;
	this.animation = {};
	
	this.frame = 0;
	this.frames = {};
	
	this.price 		= tower_params[type].price;
	this.damage 	= tower_params[type].damage;
	this.speedattack= tower_params[type].speedattack;
	this.radius 	= tower_params[type].radius;
	this.image	 	= tower_params[type].images;

	this.show_radius = false;
	this.action = tower_params[type].tower_interface_action;
	this.vector = tower_params[type].tower_interface_vector;
	
	this.update_damage		= new Array();
	this.update_radius		= new Array();
	this.update_speedattack = new Array();
	/*на будущее*/
	this.buff = new Array();
	this.debuff = new Array();

	//WELLS
	this.animation_well = 0; 	//"колодец" анимации
	this.speedattack_well = 0; 	//"колодец" скорости атаки
	
	//FUNCTIONS
	this.sold  = function(){}

	this.get_damage = function(){
		//тут алгоритм получения дамага для снаряда в зависимости от улучшений башенки и бафов/дебафов
		return this.damage;
	}
	
	this.getEnemy = function(enemy_arr, sort){
		if(enemy_arr.length == 1) return enemy_arr[0];
		if(sort == "first"){
			var first_enemy = enemy_arr[0];
			$.each(enemy_arr, function(index, enemy){
				if(enemy.distance_traveled > first_enemy.distance_traveled)
					first_enemy = enemy;
			});
		}
		return first_enemy;
	}
	
	this.shoot = function(enemy, delay, global_id){
		this.speedattack_well += this.speedattack * delay;
		if(this.speedattack_well >= 1){
			this.speedattack_well--;
			//здесь должен быть алгоритм выбора врага, но пока что будет выбираться всегда первый
			var en = this.getEnemy(enemy, "first");
			return new Trash(++global_id, this.type, en, this.get_damage(), this.current_position);
		}
		return false;
	}
	
	this.enemyInRadius = function(enemies, delay, global_id, tower){
		var current_enemy = new Array();
		$.each(enemies, function(index, enemy){
			if(!enemy.is_active) return;
			/*(x - x0)^2 + (y - y0)^2 <= R^2
			где 
				x и y - координаты точки, 
				x0 и y0 - координаты центра окружности, 
				R - радиус окружности, ^2 - возведение в квадрат. 
				Если условие выполняется, то точка находится внутри (или на окружности, в случае равенства левой и правой частей). 
				Если не выполняется, то точка вне окружности.
			*/
			if(
				(Math.pow(enemy.current_position["top"]  - tower.current_position["top"] , 2)) + 
				(Math.pow(enemy.current_position["left"] - tower.current_position["left"], 2))  
				<= Math.pow(tower.radius, 2)
			)
			current_enemy.push(enemy);
		});
		if(current_enemy.length > 0){//в поле зрения хотя бы один враг
			if(tower.action != "attack"){
				tower.action = "attack";
				tower.frame = 0;
				tower.animation_well = 0;
			}
			return this.shoot(current_enemy, delay, global_id); //возврат объекта выстрела
		}else{
			if(tower.action != "stand"){
				tower.action = "stand";
				tower.frame = 0;
				tower.animation_well = 0;
			}
			this.speedattack_well = 1 - this.speedattack * delay;
			return false;
		}
		
	}
	
	this.init = function(){
		var anim = tower_params[this.type].animation;
		var selfTower = this;
		$.each(anim, function(action, moves){
			selfTower.animation[action] = {};
			$.each(moves, function(vector, params){
				if(Object.prototype.toString.call(params.images) === '[object Array]'){
					var ia = selfTower.animation[action][vector] = new Array();
					for(var i = 0; i < params.images.length; i++){
						img = new Image();
						img.src = tower_params[selfTower.type].catalog_images + selfTower.type + "/" + params.images[i];
						ia.push(img);
					}
				}else{
					img = new Image();
					img.src = tower_params[selfTower.type].catalog_images + selfTower.type + "/" + params.images;
					selfTower.animation[action][vector] = img;
					selfTower.frames[action] =params["count_frames_width"] - params["start_from"][0] + 1 + params["end_on"][0] +
									params["count_frames_width"] * (params["end_on"][1] - params["start_from"][1] - 1);
				}
			});
			
		});
	}
	
	this.init();
}
